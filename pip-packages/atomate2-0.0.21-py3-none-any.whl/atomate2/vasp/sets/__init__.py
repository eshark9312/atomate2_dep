"""Module defining VASP input sets used in atomate2."""
