"""Output schemas for VASP calculations."""
