"""Define all FHI-aims jobs."""
