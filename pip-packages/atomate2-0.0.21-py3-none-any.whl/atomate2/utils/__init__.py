"""Common utility functions for atomate2."""
