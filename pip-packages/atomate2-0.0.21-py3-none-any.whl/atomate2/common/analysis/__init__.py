"""Common analysis functions."""
