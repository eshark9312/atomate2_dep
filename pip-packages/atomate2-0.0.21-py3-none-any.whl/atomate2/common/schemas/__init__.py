"""Common schemas used by multiple workflows."""
