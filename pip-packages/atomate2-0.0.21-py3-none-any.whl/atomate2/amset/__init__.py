"""Module for running AMSET calculations."""
