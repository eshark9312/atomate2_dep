"""Output schemas for CP2K calculations."""
