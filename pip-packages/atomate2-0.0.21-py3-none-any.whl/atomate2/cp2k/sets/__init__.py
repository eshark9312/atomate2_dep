"""Module for CP2K input sets."""
