"""Module for CP2K builders."""
