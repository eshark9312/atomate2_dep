"""Module for cp2k workflows."""
