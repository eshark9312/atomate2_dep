"""Managers run :obj:`Flow` and ;obj:`Job` objects."""
