Release notes
=============

.. toctree::
   :maxdepth: 2

   0.11.0
   0.12.0
   0.13.0
   0.14.0
   0.15.0
