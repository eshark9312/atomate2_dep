``pyfftw.builders._utils`` - Helper functions for :mod:`pyfftw.builders`
========================================================================

.. automodule:: pyfftw.builders._utils
   :members:
   :private-members:
   :exclude-members: _FFTWWrapper

   .. autoclass:: pyfftw.builders._utils._FFTWWrapper
      :members: __call__
