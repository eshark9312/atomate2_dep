:mod:`numpy.fft` interface
==========================

.. automodule:: pyfftw.interfaces.numpy_fft
   :members: fft, ifft, fft2, ifft2, fftn, ifftn, rfft, irfft, rfft2, irfft2, rfftn, irfftn, hfft, ihfft
