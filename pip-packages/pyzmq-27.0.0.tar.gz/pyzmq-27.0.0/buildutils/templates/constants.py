{original_file}

{global_assignments}

{__all__}
