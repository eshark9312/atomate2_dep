% AUTO-GENERATED FILE -- DO NOT EDIT!

# log.handlers

## Module: {mod}`zmq.log.handlers`

```{eval-rst}
.. automodule:: zmq.log.handlers
```

```{currentmodule} zmq.log.handlers
```

## Classes

### {class}`PUBHandler`

```{eval-rst}
.. autoclass:: PUBHandler
  :members:
  :undoc-members:
  :inherited-members:

```

### {class}`TopicLogger`

```{eval-rst}
.. autoclass:: TopicLogger
  :members:
  :undoc-members:
  :inherited-members:
```
