# auth.ioloop

## Module: :mod}\`zmq.auth.ioloop\`

```{eval-rst}
.. module:: zmq.auth.ioloop
```

This module is deprecated in pyzmq 25.
Use {mod}`zmq.auth.asyncio`.
