# Packaging files

This directory contains some files for some packaging systems not used by pyzmq.

These files are maintained by contributors, not updated with pyzmq releases, and not supported by pyzmq maintainers.
